module.exports = {
    transpileDependencies: true
}
