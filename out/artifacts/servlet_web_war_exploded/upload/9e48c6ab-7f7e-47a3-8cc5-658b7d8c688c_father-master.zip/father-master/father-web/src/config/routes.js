import IndexPage from "@/pages/IndexPage";
// import AdminPage from "@/pages/admin/AdminPage";

export default [
    { path: '/', component: IndexPage },
    // { path: '/admin', component: AdminPage },
]