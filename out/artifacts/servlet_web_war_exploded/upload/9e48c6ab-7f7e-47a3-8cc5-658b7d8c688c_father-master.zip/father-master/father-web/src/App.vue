<template>
  <BaseLayout/>
</template>

<script>
import BaseLayout from "@/layouts/BaseLayout";

export default {
  name: 'App',
  components: {
    BaseLayout
  }
}
</script>

<style>
</style>
