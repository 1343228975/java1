/**
 * 项目图标
 */
export const LOGO = 'http://yupi-file-1256524210.file.myqcloud.com/father/test/img/1634575583-QQ%E6%88%AA%E5%9B%BE20211019004552.png';
