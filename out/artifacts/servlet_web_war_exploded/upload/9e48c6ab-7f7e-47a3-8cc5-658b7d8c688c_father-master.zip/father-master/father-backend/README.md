# father-web

> 表情包网站 [爸爸](http://father.cool) 后端项目

## 技术栈

- Java 8
- 开发框架：SpringBoot 2.x
- 数据访问：MyBatis + MyBatis Plus
- 项目管理：Maven
- 接口文档：Swagger + Knife4j
- 数据库：MySQL
- 对象存储：Tencent COS

