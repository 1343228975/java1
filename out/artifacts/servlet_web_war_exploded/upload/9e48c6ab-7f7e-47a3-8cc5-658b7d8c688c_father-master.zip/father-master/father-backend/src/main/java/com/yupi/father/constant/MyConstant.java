package com.yupi.father.constant;

/**
 * 常量
 *
 * @author liyupi
 */
public interface MyConstant {

    /**
     * 管理员用户 id
     */
    int SYSTEM_USER_ID = 1;
}
