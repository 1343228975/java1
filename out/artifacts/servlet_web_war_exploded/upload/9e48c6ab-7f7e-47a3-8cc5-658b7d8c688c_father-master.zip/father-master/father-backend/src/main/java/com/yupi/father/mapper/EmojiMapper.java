package com.yupi.father.mapper;

import com.yupi.father.model.entity.Emoji;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * @Entity com.yupi.father.model.entitiy.Emoji
 */
public interface EmojiMapper extends BaseMapper<Emoji> {

}




