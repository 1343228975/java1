package com.yupi.father.service;

import com.yupi.father.model.entity.Emoji;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 *
 */
public interface EmojiService extends IService<Emoji> {

}
