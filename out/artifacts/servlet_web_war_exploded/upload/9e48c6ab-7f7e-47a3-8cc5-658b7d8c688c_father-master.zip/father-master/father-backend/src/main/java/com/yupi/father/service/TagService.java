package com.yupi.father.service;

import com.yupi.father.model.entity.Tag;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 *
 */
public interface TagService extends IService<Tag> {

}
