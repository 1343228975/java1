package com.yupi.father.base;

import lombok.Data;

/**
 * 删除请求参数
 * @author liyupi
 */
@Data
public class DeleteRequest {

    /**
     * id
     */
    private int id;
}
