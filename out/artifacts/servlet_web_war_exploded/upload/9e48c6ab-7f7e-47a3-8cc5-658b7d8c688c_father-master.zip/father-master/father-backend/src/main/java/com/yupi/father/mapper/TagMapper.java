package com.yupi.father.mapper;

import com.yupi.father.model.entity.Tag;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * @Entity com.yupi.father.model.entity.Tag
 */
public interface TagMapper extends BaseMapper<Tag> {

}




